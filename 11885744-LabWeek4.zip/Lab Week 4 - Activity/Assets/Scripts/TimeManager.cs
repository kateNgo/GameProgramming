﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeManager : MonoBehaviour {
	const float moveWait = 2.0f;
	const float scaleWait = 4.0f;
	private int lastTime;
	private float timer;
	private Vector3[] originalPositions = new Vector3[2];
	[SerializeField]
	private Transform[] transformArray;
	// Use this for initialization
	void Start () {
		ResetTime ();
		// Task 70%
		Camera.main.orthographic = true;
		Camera.main.orthographicSize = 2.0f;
	
	}
	
	// Update is called once per frame
	void Update () {
		// Task 40%
		/*
		if (Time.time >= (lastTime + 1)) {
			lastTime = (int)Time.time;
			Debug.Log (lastTime);
		}
		*/
		// Task 50%
		if (Input.GetKeyDown (KeyCode.Space)) {
			if (Time.timeScale != 0.0f) {
				Time.timeScale = 0.0f;
			} else {
				Time.timeScale = 1.0f;
				ResetTime ();
			}
			Debug.Log ("Spacebar pressed");
		}
		// task 60%
		timer += Time.deltaTime;
		if (timer >= (lastTime + 1)) {
			lastTime = (int)timer ;
			Debug.Log (lastTime);
			// Task 80%
			if (lastTime % 2 == 0) {
				MoveObject ();
			}
		}
		if (Input.GetKeyDown (KeyCode.KeypadEnter)) {
			ResetTime ();
		}
		if (Input.GetKeyDown (KeyCode.Escape)) {
			float randNumber = Random.Range (0.25f, 0.75f);
			StartCoroutine (RotateObjects (randNumber));
		}
	}
	private void ResetTime(){
		timer = 0.0f;
		lastTime = 0;
		Debug.Log (lastTime);
		CancelInvoke ();
		originalPositions [0] =	transformArray[0].position;
		originalPositions[1] = transformArray[1].position;
		InvokeRepeating ("ScaleObjects", scaleWait, scaleWait);
	}
	private void MoveObject(){
		switch (lastTime % 8) {
		case 0:
			transformArray [0].position = originalPositions [0];
			transformArray [1].position = originalPositions [1];
			break;
		case 2:
			transformArray [0].position = new Vector3 (originalPositions [0].x, -originalPositions [0].y, originalPositions [0].z);
			transformArray [1].position = new Vector3 (originalPositions [1].x, -originalPositions [1].y, originalPositions [1].z);
			break;
		case 4:
			transformArray [0].position = new Vector3 (-originalPositions [0].x, -originalPositions [0].y, originalPositions [0].z);
			transformArray [1].position = new Vector3 (-originalPositions [1].x, -originalPositions [1].y, originalPositions [1].z);
			break;
		case 6:
			transformArray [0].position = new Vector3 (-originalPositions [0].x, originalPositions [0].y, originalPositions [0].z);
			transformArray [1].position = new Vector3 (-originalPositions [1].x, originalPositions [1].y, originalPositions [1].z);
			break;
		default:
			break;
		}
	}
	private void ScaleObjects(){
		foreach(Transform trans in transformArray){
			if (trans.localScale.x > 1.5f) {
				trans.localScale /= 1.2f;
			} else  { //if (trans.localScale.x < 1.5f)
				trans.localScale *= 1.2f;
			}
		}
	}
	IEnumerator RotateObjects(float randomDelay){
		for (int i = 0; i < 4; i++) {
			yield return new WaitForSeconds (randomDelay);
			transformArray [0].Rotate (new Vector3 (0, 0, 90));
			transformArray [1].Rotate (new Vector3 (0, 0, 90));
		}
	}
}
